import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'json-comm-comp',
  templateUrl: './json-comm-comp.component.html',
})
export class JsonCommCompComponent implements OnInit {

  @Input() receivedJson:any = {};

  @Output() myOutput:EventEmitter<any>= new EventEmitter();

  outputMessage:any= [
    {
      color: "red",
      value: "#f00"
    },
    {
      color: "green",
      value: "#0f0"
    },
    {
      color: "blue",
      value: "#00f"
    },
    {
      color: "cyan",
      value: "#0ff"
    },
    {
      color: "magenta",
      value: "#f0f"
    },
    {
      color: "yellow",
      value: "#ff0"
    },
    {
      color: "black",
      value: "#000"
    }
  ]
  constructor(private elRef: ElementRef) {
  }
  
  
  ngOnInit(): void {
  }

  sendValues() {
    console.log('sending values');
    this.myOutput.emit(this.outputMessage);
    const event = new CustomEvent('json-comm-comp', {
      detail: {
        value: {
          message: this.outputMessage
        }
      }
    });
    this.elRef.nativeElement.dispatchEvent(event);

  }

}
