import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'custom-directive-user-action',
  templateUrl: './custom-directive-user-action.component.html',
  styleUrls: ['./custom-directive-user-action.component.css']
})
export class CustomDirectiveUserActionComponent implements OnInit {

  @Input() showDiv:boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

}
