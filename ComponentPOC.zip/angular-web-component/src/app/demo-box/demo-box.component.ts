import { Component, Inject, Input, OnInit } from '@angular/core';
import { DataService } from "./data.service";
import { Product } from "./product.model";

@Component({
  selector: 'demo-box',
  templateUrl: './demo-box.component.html',
  providers: [DataService],
})
export class DemoBoxComponent implements OnInit {

  @Input() signupTitle = 'Sign up for our newsletter';
  @Input() thankyouMessage = 'Thanks!';
  
  formData = { name: '', email: '' };
  formSubmitted = false;
  
  public listItems: Array<Product> = [];

  constructor(@Inject(DataService) private dataService: DataService) { }

  ngOnInit(): void {
    this.dataService.fetchData().subscribe((data) => (this.listItems = data));
  }

  onSubmit() {
    this.formSubmitted = true;
  }
}
