import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'child-comp',
  templateUrl: './child-comp.component.html'
})
export class ChildCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
