import { Component, Input } from '@angular/core';
@Component({
    selector: 'my-wrapper',
    template: `
    <kendo-treeview
        [nodes]="data"
        textField="text"
        kendoTreeViewExpandable
        kendoTreeViewSelectable
        kendoTreeViewHierarchyBinding
        childrenField="items"
    >
    </kendo-treeview>
  `
})
export class WrapperComponent {
  @Input() data:any;
}

