import { Component, Input, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'wrapper-kendo-comp',
  templateUrl: './wrapper-kendo-comp.component.html',
})
export class WrapperKendoCompComponent implements OnInit {

  @Input() sentData: any;
  
  // Below portion of sample data is taken from static page as input to component.
  //
  // public data: any[] = [
  //   {
  //       text: 'Furniture', items: [
  //           { text: 'Tables & Chairs' },
  //           { text: 'Sofas' },
  //           { text: 'Occasional Furniture' }
  //       ]
  //   },
  //   {
  //       text: 'Decor', items: [
  //           { text: 'Bed Linen' },
  //           { text: 'Curtains & Blinds' },
  //           { text: 'Carpets' }
  //       ]
  //   }
  // ];


  constructor() { }

  ngOnInit(): void {
  }

  // Changing the received data from static page and passing it to the component
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
    changes.sentData.currentValue[0].text = 'furniture with changes';
  }

}
