import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dynamic-comp',
  templateUrl: './dynamic-comp.component.html',
})
export class DynamicCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
