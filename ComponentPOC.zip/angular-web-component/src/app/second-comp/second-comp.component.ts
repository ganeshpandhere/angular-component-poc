import { Component, OnInit } from '@angular/core';
import { CalcService } from './calc.service';

@Component({
  selector: 'second-comp',
  templateUrl: './second-comp.component.html',
})
export class SecondCompComponent implements OnInit {

  title = 'app';
  sum: number = 0;

  name = 'Angular';
  display = false;


  constructor(calc:CalcService){
    this.sum = calc.add(1,2,3,4);
  }

  ngOnInit(): void {
  }

  onPress() {
    //this.display = true;

    //To toggle the component
    this.display = !this.display;
  }
  

}
