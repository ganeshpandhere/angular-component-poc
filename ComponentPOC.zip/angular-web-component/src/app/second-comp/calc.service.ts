import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn: 'root'
})
export class CalcService {
    constructor(private http: HttpClient) {}

    public add(...params: number[]): number {
        let result = 0;
        for (let val of params) {
            result += val;
        }
        return result;
    }
}