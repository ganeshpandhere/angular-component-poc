import { ElementRef, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { DemoBoxComponent } from './demo-box/demo-box.component';

import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule, HttpClientJsonpModule } from "@angular/common/http";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { InputsModule } from "@progress/kendo-angular-inputs";

import { PopupModule, POPUP_CONTAINER } from '@progress/kendo-angular-popup';
import { SecondCompComponent } from './second-comp/second-comp.component';
import { CalcService } from './second-comp/calc.service';
import { ChildCompComponent } from './child-comp/child-comp.component';
import { RoundBlockDirective } from './round-block.directive';
import { JsonCommCompComponent } from './json-comm-comp/json-comm-comp.component';
import { CustomDirectiveUserActionComponent } from './custom-directive-user-action/custom-directive-user-action.component';
import { WrapperKendoCompComponent } from './wrapper-kendo-comp/wrapper-kendo-comp.component';
import { WrapperComponent } from './wrapper-kendo-comp/wrapper.compoent';
import { TreeViewModule } from '@progress/kendo-angular-treeview';
import { DynamicCompComponent } from './dynamic-comp/dynamic-comp.component';

@NgModule({
  declarations: [
    DemoBoxComponent,
    SecondCompComponent,
    ChildCompComponent,
    RoundBlockDirective,
    JsonCommCompComponent,
    CustomDirectiveUserActionComponent,
    WrapperKendoCompComponent,
    WrapperComponent,
    DynamicCompComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    DropDownsModule,
    LabelModule,
    InputsModule,
    PopupModule,
    TreeViewModule
  ],
  providers: [
    CalcService,
    {
      provide: POPUP_CONTAINER,
      useFactory: () => {
         //return the container ElementRef, where the popup will be injected
         return { nativeElement: document.body } as ElementRef;
      }
    }
  ],
  bootstrap: [DemoBoxComponent]
})
export class AppModule { 
  constructor(injector: Injector) {
    const el = createCustomElement(DemoBoxComponent, { injector });
    customElements.define('demo-box', el);
    const secondComp = createCustomElement(SecondCompComponent, { injector });
    customElements.define('second-comp', secondComp);
    const childComp = createCustomElement(ChildCompComponent, { injector });
    customElements.define('child-comp', childComp);
    const customDirUsrActComp = createCustomElement(CustomDirectiveUserActionComponent, { injector });
    customElements.define('custom-directive-user-action', customDirUsrActComp);
    const jsonComp = createCustomElement(JsonCommCompComponent, { injector });
    customElements.define('json-comm-comp', jsonComp);
    const wrapperKendoComp = createCustomElement(WrapperKendoCompComponent, { injector});
    customElements.define('wrapper-kendo-comp', wrapperKendoComp);
    const dynamicComp = createCustomElement(DynamicCompComponent, { injector });
    customElements.define('dynamic-comp', dynamicComp);
  }

  ngDoBootstrap() {}
}
